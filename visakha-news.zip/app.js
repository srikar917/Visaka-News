// Visakha News Portal JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Mobile navigation toggle
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-link');

    // Toggle mobile menu
    if (navToggle) {
        navToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
            navToggle.classList.toggle('active');
            
            // Prevent body scroll when menu is open
            if (navMenu.classList.contains('active')) {
                document.body.style.overflow = 'hidden';
            } else {
                document.body.style.overflow = '';
            }
        });
    }

    // Close mobile menu when clicking on nav links
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            if (navMenu) {
                navMenu.classList.remove('active');
                document.body.style.overflow = '';
            }
            if (navToggle) {
                navToggle.classList.remove('active');
            }
        });
    });

    // Smooth scrolling for navigation links
    function handleSmoothScroll(e) {
        e.preventDefault();
        
        const href = this.getAttribute('href');
        if (!href || !href.startsWith('#')) return;
        
        const targetId = href.substring(1);
        const targetSection = document.getElementById(targetId);
        
        if (targetSection) {
            const headerOffset = 100; // Height of fixed navbar + padding
            const elementPosition = targetSection.getBoundingClientRect().top;
            const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

            window.scrollTo({
                top: offsetPosition,
                behavior: 'smooth'
            });
        }
    }

    // Apply smooth scroll to all navigation links
    navLinks.forEach(link => {
        link.addEventListener('click', handleSmoothScroll);
    });

    // Also apply to hero buttons that link to sections
    const heroSectionLinks = document.querySelectorAll('.hero-actions a[href^="#"]');
    heroSectionLinks.forEach(link => {
        link.addEventListener('click', handleSmoothScroll);
    });

    // Active navigation link highlighting - Fixed to prevent overlaps
    function updateActiveNavLink() {
        const sections = document.querySelectorAll('section[id]');
        const scrollPosition = window.scrollY + 150;

        let currentSection = '';

        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            const sectionId = section.getAttribute('id');

            if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                currentSection = sectionId;
            }
        });

        // Clear all active states first
        navLinks.forEach(link => {
            link.classList.remove('active');
        });

        // Set only the current active link
        if (currentSection) {
            const activeLink = document.querySelector(`.nav-link[href="#${currentSection}"]`);
            if (activeLink) {
                activeLink.classList.add('active');
            }
        }
    }

    // Update active nav link on scroll with throttling
    let scrollTimeout;
    window.addEventListener('scroll', function() {
        clearTimeout(scrollTimeout);
        scrollTimeout = setTimeout(updateActiveNavLink, 10);
    });
    
    // Initial call to set active nav link
    setTimeout(updateActiveNavLink, 100);

    // News category filtering
    const categoryButtons = document.querySelectorAll('.category-btn');
    const newsCards = document.querySelectorAll('.news-card');

    categoryButtons.forEach(button => {
        button.addEventListener('click', function() {
            const category = this.getAttribute('data-category');
            
            // Update active button - clear all first
            categoryButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // Clear any existing search results display
            clearSearchResults();
            
            // Filter news cards
            newsCards.forEach(card => {
                const cardCategory = card.getAttribute('data-category');
                
                if (category === 'all') {
                    card.style.display = 'block';
                    card.classList.remove('hidden');
                    card.classList.add('visible');
                } else {
                    if (cardCategory === category) {
                        card.style.display = 'block';
                        card.classList.remove('hidden');
                        card.classList.add('visible');
                    } else {
                        card.style.display = 'none';
                        card.classList.add('hidden');
                        card.classList.remove('visible');
                    }
                }
            });

            // Add smooth transition effect
            setTimeout(() => {
                const visibleCards = document.querySelectorAll('.news-card.visible');
                visibleCards.forEach((card, index) => {
                    card.style.animation = `fadeInUp 0.4s ease forwards ${index * 0.1}s`;
                });
            }, 50);

            // Show category filter results
            const visibleCount = document.querySelectorAll('.news-card.visible').length;
            showSearchResults(`Showing ${visibleCount} articles in ${category === 'all' ? 'all categories' : category + ' category'}`, 'filter');
        });
    });

    // Search functionality - Enhanced with better results display
    const searchInput = document.querySelector('.search-input');
    const searchBtn = document.querySelector('.search-btn');

    function performSearch() {
        const query = searchInput.value.toLowerCase().trim();
        
        if (!query) {
            showNotification('Please enter a search term', 'info');
            return;
        }

        // Show loading state
        searchBtn.classList.add('loading');
        searchBtn.textContent = '⏳';

        // Clear previous search highlights
        clearSearchHighlights();

        // Simulate search delay for better UX
        setTimeout(() => {
            let foundResults = 0;
            
            // Search in news cards
            newsCards.forEach(card => {
                const title = card.querySelector('.news-title').textContent.toLowerCase();
                const excerpt = card.querySelector('.news-excerpt').textContent.toLowerCase();
                const category = card.querySelector('.news-category').textContent.toLowerCase();
                
                if (title.includes(query) || excerpt.includes(query) || category.includes(query)) {
                    card.style.display = 'block';
                    card.classList.remove('hidden');
                    card.classList.add('visible');
                    foundResults++;
                    
                    // Highlight search terms
                    highlightSearchTerm(card, query);
                } else {
                    card.style.display = 'none';
                    card.classList.add('hidden');
                    card.classList.remove('visible');
                }
            });

            // Reset category buttons
            categoryButtons.forEach(btn => btn.classList.remove('active'));
            
            // Reset search button
            searchBtn.classList.remove('loading');
            searchBtn.textContent = '🔍';
            
            // Show search results
            if (foundResults > 0) {
                showSearchResults(`Found ${foundResults} result${foundResults > 1 ? 's' : ''} for "${query}"`, 'search');
                showNotification(`Found ${foundResults} articles matching "${query}"`, 'success');
                
                // Scroll to news section
                setTimeout(() => {
                    document.getElementById('news').scrollIntoView({ 
                        behavior: 'smooth',
                        block: 'start'
                    });
                }, 300);
            } else {
                showSearchResults(`No results found for "${query}"`, 'search');
                showNotification(`No articles found matching "${query}". Try different keywords.`, 'info');
            }
        }, 800);
    }

    function showSearchResults(message, type) {
        // Remove existing search results
        clearSearchResults();
        
        // Create search results display
        const newsSection = document.querySelector('.news-section .container');
        const newsGrid = document.querySelector('.news-grid');
        
        const searchResults = document.createElement('div');
        searchResults.className = 'search-results';
        searchResults.innerHTML = `
            <h3>${type === 'search' ? '🔍 Search Results' : '📁 Filter Results'}</h3>
            <p>${message}</p>
            ${type === 'search' ? '<button class="btn btn--outline btn--sm" onclick="clearSearch()">Clear Search</button>' : ''}
        `;
        
        newsSection.insertBefore(searchResults, newsGrid);
    }

    function clearSearchResults() {
        const existingResults = document.querySelector('.search-results');
        if (existingResults) {
            existingResults.remove();
        }
    }

    // Global function for clear search button
    window.clearSearch = function() {
        searchInput.value = '';
        clearSearchHighlights();
        clearSearchResults();
        
        // Show all news cards
        newsCards.forEach(card => {
            card.style.display = 'block';
            card.classList.remove('hidden');
            card.classList.add('visible');
        });
        
        // Reset active category button to "All News"
        categoryButtons.forEach(btn => {
            btn.classList.remove('active');
            if (btn.getAttribute('data-category') === 'all') {
                btn.classList.add('active');
            }
        });
        
        showNotification('Search cleared', 'info');
    };

    function highlightSearchTerm(card, query) {
        const title = card.querySelector('.news-title');
        const excerpt = card.querySelector('.news-excerpt');
        
        // Store original text if not already stored
        if (!title.dataset.originalText) {
            title.dataset.originalText = title.textContent;
        }
        if (!excerpt.dataset.originalText) {
            excerpt.dataset.originalText = excerpt.textContent;
        }
        
        [title, excerpt].forEach(element => {
            const originalText = element.dataset.originalText;
            const regex = new RegExp(`(${query})`, 'gi');
            const highlightedText = originalText.replace(regex, '<mark>$1</mark>');
            element.innerHTML = highlightedText;
        });
    }

    function clearSearchHighlights() {
        newsCards.forEach(card => {
            const title = card.querySelector('.news-title');
            const excerpt = card.querySelector('.news-excerpt');
            
            [title, excerpt].forEach(element => {
                if (element.dataset.originalText) {
                    element.innerHTML = element.dataset.originalText;
                }
            });
        });
    }

    if (searchBtn) {
        searchBtn.addEventListener('click', performSearch);
    }

    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                performSearch();
            }
        });

        // Clear search when input is cleared
        searchInput.addEventListener('input', function() {
            if (this.value.trim() === '') {
                window.clearSearch();
            }
        });
    }

    // Fade-in animation on scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, observerOptions);

    // Add fade-in class to elements and observe them
    const animatedElements = document.querySelectorAll(
        '.stat-card, .news-card, .profile-card, .service-category, ' +
        '.entertainment-card, .tourism-card, .contact-item'
    );
    
    animatedElements.forEach(element => {
        element.classList.add('fade-in');
        observer.observe(element);
    });

    // Contact form handling
    const contactForm = document.querySelector('.contact-form form');
    
    if (contactForm) {
        // Fix dropdown functionality
        const subjectSelect = document.getElementById('subject');
        if (subjectSelect) {
            subjectSelect.style.pointerEvents = 'auto';
            
            subjectSelect.addEventListener('change', function() {
                if (this.value) {
                    this.style.color = 'var(--color-text)';
                }
            });
        }

        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const subject = document.getElementById('subject').value;
            const message = document.getElementById('message').value.trim();
            
            // Clear any existing error states
            clearFormErrors();
            
            // Basic validation
            let hasErrors = false;
            
            if (!name) {
                showFieldError('name', 'Name is required');
                hasErrors = true;
            }
            
            if (!email) {
                showFieldError('email', 'Email is required');
                hasErrors = true;
            } else if (!isValidEmail(email)) {
                showFieldError('email', 'Please enter a valid email address');
                hasErrors = true;
            }
            
            if (!message) {
                showFieldError('message', 'Message is required');
                hasErrors = true;
            }
            
            if (hasErrors) {
                showNotification('Please correct the errors above.', 'error');
                return;
            }
            
            // Simulate form submission
            const submitButton = this.querySelector('button[type="submit"]');
            const originalText = submitButton.textContent;
            
            submitButton.textContent = 'Sending...';
            submitButton.disabled = true;
            
            // Simulate API call delay
            setTimeout(() => {
                showNotification('Thank you for your message! We will get back to you soon.', 'success');
                this.reset();
                
                submitButton.textContent = originalText;
                submitButton.disabled = false;
                
                // Reset subject select color
                if (subjectSelect) {
                    subjectSelect.style.color = '';
                }
            }, 1500);
        });
    }

    // Form validation helper functions
    function showFieldError(fieldId, message) {
        const field = document.getElementById(fieldId);
        if (field) {
            field.style.borderColor = 'var(--color-error)';
            
            // Remove existing error message
            const existingError = field.parentNode.querySelector('.field-error');
            if (existingError) {
                existingError.remove();
            }
            
            // Add error message
            const errorDiv = document.createElement('div');
            errorDiv.className = 'field-error';
            errorDiv.textContent = message;
            errorDiv.style.cssText = `
                color: var(--color-error);
                font-size: var(--font-size-sm);
                margin-top: var(--space-4);
            `;
            field.parentNode.appendChild(errorDiv);
        }
    }

    function clearFormErrors() {
        const errorMessages = document.querySelectorAll('.field-error');
        errorMessages.forEach(error => error.remove());
        
        const formFields = document.querySelectorAll('.form-control');
        formFields.forEach(field => {
            field.style.borderColor = '';
        });
    }

    // Email validation function
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    // Notification system
    function showNotification(message, type = 'info') {
        // Remove any existing notifications
        const existingNotification = document.querySelector('.notification');
        if (existingNotification) {
            existingNotification.remove();
        }

        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification notification--${type}`;
        
        const backgroundColor = type === 'success' 
            ? 'rgba(var(--color-success-rgb), 0.9)' 
            : type === 'error' 
            ? 'rgba(var(--color-error-rgb), 0.9)' 
            : 'rgba(var(--color-info-rgb), 0.9)';

        notification.innerHTML = `
            <div class="notification-content" style="display: flex; align-items: center; justify-content: space-between;">
                <span class="notification-message">${message}</span>
                <button class="notification-close" style="background: none; border: none; color: white; font-size: 18px; cursor: pointer; padding: 0 0 0 16px;" aria-label="Close notification">×</button>
            </div>
        `;

        // Add styles for notification
        notification.style.cssText = `
            position: fixed;
            top: 100px;
            right: 20px;
            z-index: 1001;
            background: ${backgroundColor};
            color: white;
            padding: 16px 20px;
            border-radius: var(--radius-base);
            box-shadow: var(--shadow-lg);
            max-width: 400px;
            min-width: 300px;
            transform: translateX(100%);
            transition: transform 0.3s ease;
            font-weight: var(--font-weight-medium);
        `;

        // Add to DOM
        document.body.appendChild(notification);

        // Animate in
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);

        // Handle close button
        const closeButton = notification.querySelector('.notification-close');
        if (closeButton) {
            closeButton.addEventListener('click', () => {
                hideNotification(notification);
            });
        }

        // Auto hide after 5 seconds
        setTimeout(() => {
            if (document.body.contains(notification)) {
                hideNotification(notification);
            }
        }, 5000);
    }

    function hideNotification(notification) {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (document.body.contains(notification)) {
                notification.remove();
            }
        }, 300);
    }

    // Add hover effects to cards
    const cards = document.querySelectorAll(
        '.stat-card, .news-card, .profile-card, .service-category, ' +
        '.entertainment-card, .tourism-card'
    );
    
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            if (!this.classList.contains('news-card')) {
                this.style.transform = 'translateY(-2px)';
            }
            this.style.transition = 'transform 0.2s ease';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });

    // Handle window resize for mobile menu
    window.addEventListener('resize', function() {
        if (window.innerWidth > 768) {
            if (navMenu) {
                navMenu.classList.remove('active');
                document.body.style.overflow = '';
            }
            if (navToggle) navToggle.classList.remove('active');
        }
    });

    // Add scroll-based navbar background opacity
    function updateNavbarOpacity() {
        const header = document.querySelector('.header');
        if (!header) return;
        
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        if (scrollTop > 50) {
            header.style.background = 'rgba(var(--color-surface), 0.95)';
            header.style.backdropFilter = 'blur(10px) saturate(180%)';
        } else {
            header.style.background = 'var(--color-surface)';
            header.style.backdropFilter = 'blur(10px)';
        }
    }

    let navbarTimeout;
    window.addEventListener('scroll', function() {
        clearTimeout(navbarTimeout);
        navbarTimeout = setTimeout(updateNavbarOpacity, 10);
    });
    
    // Initialize navbar opacity
    updateNavbarOpacity();

    // Add keyboard navigation support
    document.addEventListener('keydown', function(e) {
        // Close mobile menu on Escape key
        if (e.key === 'Escape') {
            if (navMenu) {
                navMenu.classList.remove('active');
                document.body.style.overflow = '';
            }
            if (navToggle) navToggle.classList.remove('active');
        }
    });

    // Add click outside to close mobile menu
    document.addEventListener('click', function(e) {
        if (navToggle && navMenu && 
            !navToggle.contains(e.target) && 
            !navMenu.contains(e.target)) {
            navMenu.classList.remove('active');
            navToggle.classList.remove('active');
            document.body.style.overflow = '';
        }
    });

    // News card click to expand/show more details
    newsCards.forEach(card => {
        card.addEventListener('click', function() {
            const title = this.querySelector('.news-title').textContent;
            const category = this.querySelector('.news-category').textContent;
            
            showNotification(`${category}: ${title.substring(0, 60)}${title.length > 60 ? '...' : ''}`, 'info');
        });
    });

    // Entertainment card interactions
    const entertainmentCards = document.querySelectorAll('.entertainment-card');
    entertainmentCards.forEach(card => {
        card.addEventListener('click', function() {
            const title = this.querySelector('h3').textContent;
            showNotification(`${title} - Feature coming soon!`, 'info');
        });
    });

    // Tourism card interactions
    const tourismCards = document.querySelectorAll('.tourism-card');
    tourismCards.forEach(card => {
        card.addEventListener('click', function() {
            const title = this.querySelector('h3').textContent;
            showNotification(`Learn more about ${title} - Tourism guide coming soon!`, 'info');
        });
    });

    // Add loading state management
    window.addEventListener('load', function() {
        document.body.classList.add('loaded');
        
        // Trigger initial animations for hero section
        const heroElements = document.querySelectorAll('#home .stat-card');
        heroElements.forEach((element, index) => {
            setTimeout(() => {
                element.classList.add('visible');
            }, index * 150 + 500);
        });
    });

    // Add CSS for animations dynamically
    const style = document.createElement('style');
    style.textContent = `
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        mark {
            background: var(--color-orange-400) !important;
            color: var(--color-text) !important;
            padding: 2px 4px !important;
            border-radius: 3px !important;
        }
    `;
    document.head.appendChild(style);

    // Initialize page
    console.log('Visakha News portal loaded successfully!');
    
    // Set initial focus and accessibility
    const skipLink = document.createElement('a');
    skipLink.href = '#home';
    skipLink.textContent = 'Skip to main content';
    skipLink.className = 'sr-only';
    skipLink.style.cssText = `
        position: absolute;
        top: -40px;
        left: 6px;
        background: var(--color-primary);
        color: var(--color-btn-primary-text);
        padding: 8px;
        z-index: 1000;
        text-decoration: none;
        border-radius: 4px;
    `;
    
    skipLink.addEventListener('focus', function() {
        this.style.top = '6px';
    });
    
    skipLink.addEventListener('blur', function() {
        this.style.top = '-40px';
    });
    
    document.body.insertBefore(skipLink, document.body.firstChild);

    // Welcome message
    setTimeout(() => {
        showNotification('Welcome to Visakha News - Your trusted source for Vizag updates! 📰', 'success');
    }, 2000);
});